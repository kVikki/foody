<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'test2' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ']8|kY.W9LW^dH#^0,y(~k7)C!m8qB%o0YH/@B+G,)h@gQ5ZFB 5)Tn3)=,6>SHY9' );
define( 'SECURE_AUTH_KEY',  'b`=XW&|>hX{aoGDJ:eewj =)]I#J$` +*W|*jR.3.E]xqbYB{kR>;m; 7QTmio;v' );
define( 'LOGGED_IN_KEY',    '(Vi.:<RJ,9S)r:TaKxtq{>Op6Cbr cX?B0]<?OdQ&LgZgOwdu4u@wVU$$PHa~jea' );
define( 'NONCE_KEY',        'S|5pS{4vj8OD+F(5iCL=ic3cN_)/F;jPNF&Ui0DdodvLN``[|!XZlvO{)Y6t OpH' );
define( 'AUTH_SALT',        '3aNCH-/qc3~CSRrbE=DC&(`qmxc r(!{-iY1e-#A:0ZS[O- 7gqIg1`2wn9@jb=w' );
define( 'SECURE_AUTH_SALT', '%Y^?@>aSBJoHpUPgE-`PN3<,sey_>5?KshyGE]b*UY8bG:+J!E^q%A44AFsd^}.}' );
define( 'LOGGED_IN_SALT',   '1r}7kzLVYdJ[%$K#^Tup&k/@9yC4tiZ(_7H|+$%,p4h*tReFtP,op6?W!vjGlD5+' );
define( 'NONCE_SALT',       'X[@UTPvT1(JBjp.7;,xm}J8n[o{(C.PrLPC%Zi[_.8%-(Z#]8Mh!rW@0^0Gq1EE*' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
